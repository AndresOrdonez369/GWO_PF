function euclideanDistance = CalcDistance(x1, y1, x2, y2) 
    euclideanDistance = sqrt((x2-x1)^2+(y2-y1)^2); %calcular la distancia eucilidiana entre 2 puntos
end